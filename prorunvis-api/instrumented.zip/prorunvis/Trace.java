package prorunvis;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
public final class Trace {
    public static void next_elem(int num) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter("Trace.tr", true))) {
            writer.write("" + num + System.lineSeparator());
        } catch (IOException e) {
            throw new RuntimeException(e.getMessage());
        }
    }
}
