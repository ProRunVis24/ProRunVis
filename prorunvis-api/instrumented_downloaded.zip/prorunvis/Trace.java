package prorunvis;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

public final class Trace {
    // These fields allow manual forcing of a trace
    public static int[] trace = null;
    public static int index = 0;

    public static void next_elem(int num) {
        if (trace != null && index < trace.length) {
            num = trace[index];
            index++;
        }
        try (BufferedWriter writer = new BufferedWriter(new FileWriter("Trace.tr", true))) {
            writer.write("" + num + System.lineSeparator());
        } catch (IOException e) {
            throw new RuntimeException(e.getMessage());
        }
    }
}
